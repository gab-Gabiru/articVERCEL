@echo off
setlocal
cd /d "%~dp0Artic_MSSQL_Reliable_Fixed"
call start_artic.bat
