ARTIC V14 - LOCALHOST START

1. Make sure SQL Server (SQLEXPRESS03) is running.
2. Double-click START_HERE.bat.
3. Open the URL printed by the launcher.
4. The app tries Windows Authentication first for local SQL Server, then SQL Authentication.
5. Health check: /health.php

Default database: artic
Default SQL fallback: sa / Testing123!

If the app opens but database features fail, open /health.php. It now reports the authentication mode and the exact SQL Server error.
