# Logo Update

The header now uses the supplied `Logo/Artic Logo transparent bg.png`.
A web-served copy is included at `Artic_MSSQL_Reliable_Fixed/assets/artic-logo.png` so it works when the application folder itself is the localhost document root.
