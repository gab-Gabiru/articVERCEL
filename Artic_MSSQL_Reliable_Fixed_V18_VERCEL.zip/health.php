<?php

declare(strict_types=1);

require_once __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$config = artic_local_config();
$driverLoaded = extension_loaded('pdo_sqlsrv');
$configReady = !empty($config)
    && !empty($config['server'])
    && !empty($config['database'])
    && (
        !empty($config['trusted_connection'])
        || (isset($config['username']) && (string)$config['username'] !== '' && isset($config['password']) && (string)$config['password'] !== '')
    );

try {
    if (!$driverLoaded) {
        throw new RuntimeException('PDO_SQLSRV is not enabled in this PHP runtime.');
    }

    $pdo = db();
    $stmt = $pdo->query('SELECT DB_NAME() AS database_name, @@SERVERNAME AS server_name');
    $info = $stmt->fetch();

    $missing = function_exists('required_schema_objects')
        ? required_schema_objects($pdo)
        : [];

    echo json_encode([
        'ok' => true,
        'ready' => count($missing) === 0,
        'database' => $info['database_name'] ?? null,
        'server' => $info['server_name'] ?? null,
        'pdo_driver' => $pdo->getAttribute(PDO::ATTR_DRIVER_NAME),
        'pdo_sqlsrv_loaded' => true,
        'config_present' => $configReady,
        'missing_schema_objects' => $missing,
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    error_log($e->getMessage());
    echo json_encode([
        'ok' => false,
        'ready' => false,
        'pdo_sqlsrv_loaded' => $driverLoaded,
        'config_present' => $configReady,
        'error' => 'Database health check failed.',
        'details' => $e->getMessage(),
        'next_step' => !$driverLoaded
            ? 'Enable PDO_SQLSRV in the PHP runtime used by localhost.'
            : (!$configReady ? 'Open setup.php and save your SQL Server connection settings.' : 'Open setup.php and test/repair the Artic database.'),
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}
