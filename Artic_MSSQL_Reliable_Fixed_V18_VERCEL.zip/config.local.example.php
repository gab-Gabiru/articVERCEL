<?php
return [
    'server' => 'localhost\\SQLEXPRESS03',
    'port' => '',
    'database' => 'artic',
    'username' => 'sa',
    'password' => null,
    'trusted_connection' => true,
    'encrypt' => true,
    'trust_server_certificate' => true,
    'login_timeout' => 5,
    'allow_windows_fallback' => true,
];
