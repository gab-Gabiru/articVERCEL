<?php

// Copy this file to config.local.php and enter your SQL Server settings.
// This file is safe to keep in the project as an example; do not put a real
// password into the example file.
return [
    // Preferred for a local SQL Server Express named instance.
    'server' => 'localhost\\SQLEXPRESS03',
    // Leave empty when SQL Browser is enabled. If you know the TCP port,
    // e.g. 1433, set it here and the app will use TCP directly.
    'port' => '',
    'database' => 'artic',

    // SQL Server Authentication:
    'username' => 'sa',
    'password' => 'PUT_YOUR_SQL_SERVER_PASSWORD_HERE',

    // Set true only if the SQL Server Windows account running PHP/Apache has
    // a SQL Server login. For php -S, this is normally your Windows user.
    'trusted_connection' => false,

    // Local-development defaults. The app also falls back to Encrypt=false
    // for localhost if the encrypted connection fails.
    'encrypt' => true,
    'trust_server_certificate' => true,
    'login_timeout' => 8,
    // Local development: if SQL auth for sa is rejected, try Windows Authentication.
    'allow_windows_fallback' => true,
];
